@echo off
cd /d %~dp0

for %%i in (*.hdr) do (
	md %%~ni
	.\cli.exe -inputPath .\%%i -outCubeMap .\%%~ni\specular_pmrem.ktx2 -distribution GGX -outLUT .\lut_ggx.png -sampleCount 1024 -mipLevelCount 5 -cubeMapResolution 1024 -targetFormat R16G16B16A16_SFLOAT
	.\cli.exe -inputPath .\%%i -outCubeMap .\%%~ni\diffuse_iem.ktx2 -distribution Lambertian -sampleCount 1024 -mipLevelCount 5 -cubeMapResolution 1024 -targetFormat R16G16B16A16_SFLOAT
	.\cli.exe -inputPath .\%%i -outCubeMap .\%%~ni\sheen_pmrem.ktx2 -distribution Charlie -outLUT .\lut_charlie.png -sampleCount 1024 -mipLevelCount 5 -cubeMapResolution 1024 -targetFormat R16G16B16A16_SFLOAT
	move /Y .\%%i .\%%~ni
)